import shed.mbed.*;
import java.util.*;
import java.lang.Object.*;
/**
 * This program prints the direction of the joystick to the LCD
 * screen when it is pressed LEFT, RIGHT, or FIRE. Additionally
 * the left and right motion of the joystick also toggle the two
 * LEDs.
 *
 * Your task is to modify the program so that the left and right
 * motion now picks which LED to toggle and pressing the joystick
 * toggles that LED. Which way and if it still prints out the
 * messages to the LCD are left up to you.
 * 
 * @author djb + ash
 * @version 2015.01.05
 */
public class Program
{
    // The object for interacting with the FRDM/MBED.
    private MBed mbed;

    private long startTime;

    private long endTime;

    private long elapsedTime;

    private int screenselect =1;

    /**
     * Open a connection to the MBED.
     */
    public Program()
    {
        mbed = MBedUtils.getMBed();
        startTime = 0;
        endTime = 0;
        elapsedTime = 0;

    }

    /**
     * The starting point for the interactions.
     */
    public void run()
    {
        Potentiometer pott = mbed.getPotentiometer1();
        pott.addListener((double potvalue)->potUpdate(pott));
        while(mbed.isOpen()){
            potUpdate(pott);
        }
    }

    private void potUpdate(Potentiometer pot){
        System.out.println(pot.getValue());
        if(pot.getValue()<=0.33){
            screenselect=1;
            sleep(1000);
            checkscreenUpdate();
        } else if(pot.getValue()<0.66){
            screenselect=2;
            checkscreenUpdate();
            sleep(1000);

        } else if (pot.getValue()>0.66){
            screenselect=3;
            checkscreenUpdate();
            sleep(1000);
        } else {
            screen1();
        }
    }

    private void checkscreenUpdate(){
        if(screenselect ==1){
            screen1();
        } else if (screenselect ==2){
            screen2();
        }else if (screenselect ==3){
            screen3();
        }
    }

    private void screen1(){
        Accelerometer accelerometer = mbed.getAccelerometerBoard();
        LCD lcd = mbed.getLCD();

        LED board = mbed.getLEDBoard();
        LED shield = mbed.getLEDShield();
        if(accelerometer.getAcceleration().getMagnitude() > 0.5)
        {
            startTime();
            while(mbed.isOpen()&&screenselect==1) {
                lcd.print(-1,-1, "Average speed:" + Math.round(accelerometer.getAcceleration().getMagnitude()) + "mph");
                lcd.print(-1,10, "Time active:" + ((System.currentTimeMillis()/1000) - (startTime)/1000) + "s");
                if(elapsedTime !=0){
                    lcd.print(-1,5,"Distance Traveled:" + (Math.round(accelerometer.getAcceleration().getMagnitude())/elapsedTime)+"Miles");
                }
                sleep(1000);
            }
        }
        else if((accelerometer.getAcceleration().getMagnitude() > 0.5) && elapsedTime > 0)
        {
            startTime();
            while(mbed.isOpen()&&screenselect==1) {
                elapsedTime ++;
                lcd.print(-1,-1, "Average speed:" + Math.round(accelerometer.getAcceleration().getMagnitude()) + "mph");
                lcd.print(-1,10, "Time active:" + (elapsedTime + "s"));
                lcd.print(-1,20,"Distance Traveled:" + (Math.round(accelerometer.getAcceleration().getMagnitude())/elapsedTime)+"Miles");
                sleep(1000);
            }

        }
        else
        {
            endTime();
            if(elapsedTime == 0)
            {
                elapsedTime = endTime - startTime;
                while(mbed.isOpen()&&screenselect==1)
                {
                    lcd.print(-1,10, "Time active:" + elapsedTime + "s");
                    sleep(1000);
                }
            }
            else
            {
                while(mbed.isOpen()&&screenselect==1)
                {
                    lcd.print(-1,10, "Time active:" + elapsedTime + "s");
                    sleep(1000);
                }            
            }
        }
    }

    private void screen2(){
        while(mbed.isOpen()){
        }
    }

    private void screen3(){
        while(mbed.isOpen()){
        }
    }

    /**
     * Close the connection to the MBED.
     */
    public void finish()
    {
        mbed.close();
    }

    /**
     * A simple support method for sleeping the program.
     * @param millis The number of milliseconds to sleep for.
     */
    private void sleep(int millis)
    {
        try {
            Thread.sleep(millis);
        } 
        catch (InterruptedException ex) {
            // Nothing we can do.
        }
    }

    private void startTime()
    {
        startTime = System.currentTimeMillis();
    }

    private void endTime()
    {
        endTime = System.currentTimeMillis();
    }

}
